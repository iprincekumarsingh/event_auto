REFUND AND CANCELLATION

<p> are not responsible for refunds on payment issues caused by your bank or UPI apps.<p>

<p>Organisers are not responsible for refunds if you are unable to reach venue.</p>

<p>Organisers are not responsible for refunds if programme is delayed or canceled due to act of God.</p>

<p>Organisers are not responsible for refunds if programme has started but ended early the the promised times.</p>

<p>Organisers are not responsible for refunds if you are willing to cancel tickets due to personal reasons</p>

<p>No cancellation can be made once the ticked in purchased.</p>

<p>No cancelation due to act of God, or any other legal issue faced by organisers as well as the customer</p>
