<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>
<body>
    <h1>Phone  :{{session('title')}}</h1>
    <br>
    <h1>Email  :{{session('emailcontact')}}</h1>
    <br>
    <h1>Phone :{{session('phoneCon')}}</h1>
    <br>
    <p>Phone :{{session('query')}}</[]>
    <br>


</body>
</html>
