<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="<?php echo e(url('css/output.css')); ?>">
    <title>signup</title>
</head>

<body>

    <section class="px-4 py-16 mx-auto max-w-screen-xl sm:px-6 lg:px-8">
        <div class="max-w-lg mx-auto">
            <h1 class="text-2xl font-bold text-center text-indigo-600 sm:text-3xl">
                Sign Up
            </h1>

            <form action="<?php echo e(route('auth.register')); ?>" method="POST"
                class="p-8 mt-6 mb-0 rounded-lg shadow-2xl space-y-4">
                <?php echo csrf_field(); ?>
                <p class="text-lg font-medium">Sign up for your account</p>
                <div class="col-span-3">
                    <label class="block mb-1 text-sm " for="name">
                        Name
                    </label>

                    <input name="name" class="rounded-lg shadow-sm border-gray-200 w-full text-sm p-2.5" type="text"
                        id="name" />
                    <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span style="color:red" class="invalid-feedback" role="alert">
                        <strong><?php echo e($message); ?></strong>
                    </span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <div class="col-span-6">
                    <label class="block mb-1 text-sm " for="email">
                        Email
                    </label>

                    <input name="email" class="rounded-lg shadow-sm border-gray-200 w-full text-sm p-2.5" type="email"
                        id="email" />
                    <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span style="color:red" class="invalid-feedback" role="alert">
                        <strong><?php echo e($message); ?></strong>
                    </span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <div class="col-span-6">
                    <label class="block mb-1 text-sm " for="phone">
                        Password
                    </label>

                    <input name="password" class="rounded-lg shadow-sm border-gray-200 w-full text-sm p-2.5" type="tel"
                        id="phone" />
                        <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span style="color:red" class="invalid-feedback" role="alert">
                            <strong><?php echo e($message); ?></strong>
                        </span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <button type="submit"
                    class="block w-full px-5 py-3 text-sm font-medium text-white bg-indigo-600 rounded-lg">
                    Sign up
                </button>

                <p class="text-sm text-center text-gray-500 capitalize">
                    already have an account?
                    <a class="underline" href="<?php echo e(route('auth.index')); ?>">log in</a>
                </p>
            </form>
        </div>
    </section>

</body>

</html>
<?php /**PATH C:\Users\princ\OneDrive\Desktop\event\resources\views/auth/register.blade.php ENDPATH**/ ?>